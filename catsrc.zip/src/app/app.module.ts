import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategorylistComponent } from './Category/categorylist.component';
import { CreateCategoryComponent } from 'src/app/createcategory/create-category.component';
import { UpdateCategoryComponent } from 'src/app/updatecategory/update-category.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    CategorylistComponent,
    CreateCategoryComponent,
    UpdateCategoryComponent,
    
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
