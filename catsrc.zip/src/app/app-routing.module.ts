import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategorylistComponent } from './Category/categorylist.component';
import { CreateCategoryComponent } from './createcategory/create-category.component';
import { UpdateCategoryComponent } from './updatecategory/update-category.component';

const routes: Routes = [
  {path:'Categorylist',component:CategorylistComponent},
  {path:'create',component:CreateCategoryComponent},
  {path:'updatecategory',component: UpdateCategoryComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
