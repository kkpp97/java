package com.capgemini.bank.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BSException;

public interface BankingSoftwareDao {

	long registerDetails(Account account);

	Map<Long, Account> viewCustomerDetails(Account account1);

	boolean amountDeposit(long accountNumber, double amount);

	boolean amountWithdraw(long accountNumber, double amount);

	double viewBalance(long accountNumber) throws BSException;

	long fundTransfer(long receiverAccountNumber, long senderAccountNumber, double amount);

	List<Transaction> showAllTransactions(long accountNumber);

	Account getAccountDetails(long accNumber);
}
