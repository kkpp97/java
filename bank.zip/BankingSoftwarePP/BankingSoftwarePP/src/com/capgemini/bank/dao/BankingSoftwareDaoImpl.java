package com.capgemini.bank.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;


import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BSException;
import com.capgemini.bank.utility.BankingRepository;

public class BankingSoftwareDaoImpl implements BankingSoftwareDao {

	public Map<Long, Account> detailStorage = BankingRepository.getDetailStorage();
	public Map<Long, Transaction> transactionList = BankingRepository.getTransactionList();
	long generatedAccountNum = 800000000000L;
	Account account = null;
	double balance = 0;
	int noOfTransaction = 0;
	static long transactionNumber = 3000000000L;

	BankingRepository repository = new BankingRepository();
	
	@Override
	public long registerDetails(Account account) {

		generatedAccountNum++;
		// long generatedAccountNum= (long) (Math.random()*1000000000);
		account.setAccountNumber(generatedAccountNum);
		detailStorage.put(generatedAccountNum, account);

		return generatedAccountNum;
	}

	@Override
	public Map<Long, Account> viewCustomerDetails(Account account1) {

		return detailStorage;
	}

	@Override
	public boolean amountDeposit(long accountNumber, double amount) {
		boolean depositFlag = false;
		DateFormat df = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
		Date date = new Date();
		String accountOpenDate = df.format(date);
		
		Transaction transaction=new Transaction();
		
		//System.out.println(detailStorage.get(accountNumber) );
		if (detailStorage.get(accountNumber) != null) {
			depositFlag = true;
			account = detailStorage.get(accountNumber);
			balance = account.getBalance();
			balance = balance + amount;
			account.setBalance(balance);
			detailStorage.put(accountNumber, account);
			
			transaction.setDestinationAccountNum(accountNumber);
			transaction.setSourceAccountNum(accountNumber);
			transaction.setAmount(amount);
			transaction.setTransactionDate(accountOpenDate );
			transaction.setTransactionType("Credit");
			transactionNumber++;
			System.out.println("Transaction Id: "+transactionNumber);
			transaction.setTransactionId(transactionNumber);
			transactionList.put(transactionNumber, transaction);
		} else {
			depositFlag = false;
			System.err.println("Account doesnt exist");
		}
       
		return depositFlag;
	}

	@Override
	public boolean amountWithdraw(long accountNumber, double amount) {
		boolean withdrawFlag = false;
		DateFormat df = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
		Date date = new Date();
		String accountOpenDate = df.format(date);
		
		Transaction transaction=new Transaction();
		
		
		if (detailStorage.get(accountNumber) != null) {
			withdrawFlag = true;
			account = detailStorage.get(accountNumber);
			balance = account.getBalance();
			balance = balance - amount;
			account.setBalance(balance);
			detailStorage.put(accountNumber, account);
			noOfTransaction++;
			
			transaction.setDestinationAccountNum(accountNumber);
			transaction.setSourceAccountNum(accountNumber);
			transaction.setAmount(amount);
			transaction.setTransactionDate(accountOpenDate );
			transaction.setTransactionType("Debit");
			
			transactionList.put((++transactionNumber), transaction);
			System.out.println("Transaction Id: "+ transactionNumber);
			transaction.setTransactionId(transactionNumber);
			
		} else {
			withdrawFlag = false;
			System.err.println("Account doesn't exist");
		}
		return withdrawFlag;
	}

	@Override
	public double viewBalance(long accountNumber) throws BSException {
		if(detailStorage.get(accountNumber)!=null) {
		Account account=detailStorage.get(accountNumber);
		return account.getBalance();
		}else {
			throw new BSException("Account doesn't exist");
		}
	}

	@Override
	public long fundTransfer(long receiverAccountNumber, long senderAccountNumber, double amount) {
		DateFormat df = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
		Date date = new Date();
		String accountOpenDate = df.format(date);
		
		Transaction transaction=new Transaction();
		transaction.setDestinationAccountNum(receiverAccountNumber);
		transaction.setSourceAccountNum(senderAccountNumber);
		transaction.setAmount(amount);
		transaction.setTransactionDate(accountOpenDate );
		transaction.setTransactionType("Debit");
		transactionList.put(++transactionNumber, transaction);//Because we want our transaction id to increment everytime
		transaction.setTransactionId(transactionNumber);
		
		if (detailStorage.containsKey(senderAccountNumber)) {
			Account account = detailStorage.get(senderAccountNumber);
			balance= account.getBalance();
			balance = balance - amount;
			account.setBalance(balance);
			detailStorage.put(senderAccountNumber,account );
		} else {
			System.err.println("Account doesn't exist");
		}

		if (detailStorage.containsKey(receiverAccountNumber)) {
			Account account = detailStorage.get(receiverAccountNumber);
			balance = account.getBalance();
			balance = balance + amount;
			account.setBalance(balance);
			detailStorage.put(receiverAccountNumber, account);
		} else {
			
			System.err.println("Account doesn't exist");
		}
		transactionNumber++;
		return transactionNumber;
		
	}

	@Override
	public List<Transaction> showAllTransactions(long accountNumber) {
		List<Transaction> transactions = new ArrayList<Transaction>();
		for(Map.Entry<Long, Transaction> entry:transactionList.entrySet()) {
			
			
			  if(entry.getValue().getDestinationAccountNum()== accountNumber ||
			  entry.getValue().getSourceAccountNum()==accountNumber) {
			  transactions.add(entry.getValue());  };
			 
			//transactions.add(entry.getValue()); 
		}
		return transactions;
	}
	
	public Account getAccountDetails(long accNumber) {
		return detailStorage.get(accNumber);
	}

}
