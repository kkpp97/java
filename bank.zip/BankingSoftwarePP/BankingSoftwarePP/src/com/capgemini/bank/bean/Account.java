package com.capgemini.bank.bean;

import java.util.List;

public class Account {

	private long accountNumber;
	private String accountHolderName;
	private String accountHolderEmail;
	private String accountHolderAddress;
	private long mobileNumber;
	private double balance;
	private String accountOpenDate;
	private int noOfTransactions;
	private List<Transaction> transaction;
	
	public Account() {
		super();
	}
	
	
	
	public Account(long accountNumber, String accountHolderName, String accountHolderEmail, String accountHolderAddress,
			long mobileNumber, double balance, String accountOpenDate, int noOfTransactions) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountHolderEmail = accountHolderEmail;
		this.accountHolderAddress = accountHolderAddress;
		this.mobileNumber = mobileNumber;
		this.balance = balance;
		this.accountOpenDate = accountOpenDate;
		this.noOfTransactions = noOfTransactions;
	}



	public Account(long accountNumber, String accountHolderName, String accountHolderEmail, String accountHolderAddress,
			long mobileNumber, double balance, String accountOpenDate, int noOfTransactions,
			List<Transaction> transaction) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountHolderEmail = accountHolderEmail;
		this.accountHolderAddress = accountHolderAddress;
		this.mobileNumber = mobileNumber;
		this.balance = balance;
		this.accountOpenDate = accountOpenDate;
		this.noOfTransactions = noOfTransactions;
		this.transaction = transaction;
	}


	public long getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getAccountHolderName() {
		return accountHolderName;
	}


	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	public String getAccountHolderEmail() {
		return accountHolderEmail;
	}


	public void setAccountHolderEmail(String accountHolderEmail) {
		this.accountHolderEmail = accountHolderEmail;
	}


	public String getAccountHolderAddress() {
		return accountHolderAddress;
	}


	public void setAccountHolderAddress(String accountHolderAddress) {
		this.accountHolderAddress = accountHolderAddress;
	}


	public long getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public String getAccountOpenDate() {
		return accountOpenDate;
	}


	public void setAccountOpenDate(String accountOpenDate) {
		this.accountOpenDate = accountOpenDate;
	}


	public int getNoOfTransactions() {
		return noOfTransactions;
	}


	public void setNoOfTransactions(int noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}


	public List<Transaction> getTransaction() {
		return transaction;
	}


	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}


	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", accountHolderEmail=" + accountHolderEmail + ", accountHolderAddress=" + accountHolderAddress
				+ ", mobileNumber=" + mobileNumber + ", balance=" + balance + ", accountOpenDate=" + accountOpenDate
				+ ", noOfTransactions=" + noOfTransactions + ", transaction=" + transaction + "]";
	}


	
	
	
}
