package com.capgemini.bank.bean;

public class Transaction {

	private long transactionId;
	private String transactionType;
	private String transactionDate;
	//private int customerId;
	private long sourceAccountNum;
	private long destinationAccountNum;
	private double amount;

	public Transaction() {
		super();

	}

	public Transaction(long transactionId, String transactionType, String transactionDate, 
			long sourceAccountNum, long destinationAccountNum, double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		//this.customerId = customerId;
		this.sourceAccountNum = sourceAccountNum;
		this.destinationAccountNum = destinationAccountNum;
		this.amount = amount;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	/*
	 * public int getCustomerId() { return customerId; }
	 * 
	 * public void setCustomerId(int customerId) { this.customerId = customerId; }
	 */

	public long getSourceAccountNum() {
		return sourceAccountNum;
	}

	public void setSourceAccountNum(long sourceAccountNum) {
		this.sourceAccountNum = sourceAccountNum;
	}

	public long getDestinationAccountNum() {
		return destinationAccountNum;
	}

	public void setDestinationAccountNum(long destinationAccountNum) {
		this.destinationAccountNum = destinationAccountNum;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", sourceAccountNum="
				+ sourceAccountNum + ", destinationAccountNum=" + destinationAccountNum + ", amount=" + amount + "]";
	}

}
