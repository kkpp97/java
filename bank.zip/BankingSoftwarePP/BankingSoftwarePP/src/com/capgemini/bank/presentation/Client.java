package com.capgemini.bank.presentation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BSException;
import com.capgemini.bank.service.BankingSoftwareService;
import com.capgemini.bank.service.BankingSoftwareServiceImpl;

public class Client {

	public static void main(String[] args) {

		System.out.println("\t\t\t\t Welcome to Banking System");

		BankingSoftwareService service = new BankingSoftwareServiceImpl();
		Account account1 = new Account();
		Transaction transaction1 = new Transaction();

		Scanner scanner = null;
		String option = "";
		String name = "";
		String mailId = "";
		boolean mailIdFlag = false;
		long mobile = 0;
		double amount = 0;
		String address = "";
		String accountOpenDate = "";
		int noOfTransactions = 0;
		double initialBalance = 0;
		double finalBalance = 0;
		long generatedTransactionId = 0;
		int choice = 0;
		long accountNumber = 0;
		long receiverAccountNumber = 0;
		long senderAccountNumber = 0;
		boolean optionFlag = false;
		boolean choiceFlag = true;
		boolean depositFlag = false;
		boolean withdrawFlag = true;
		boolean flag = false;
		boolean viewFlag = false;
		boolean receiverFlag = false;
		boolean senderFlag = false;
		boolean amountFlag = false;
		boolean accountFlag = false;
		do {
			do {
				System.out.println(
						" 1. Create Account \n 2. Deposit Amount \n 3. Withdraw Amount \n 4. View Account Balance \n 5. Fund Transfer \n 6. All Transactions \n 7. View Customer Details \n 8. Exit ");
				System.out.println("Enter your choice");
				scanner = new Scanner(System.in);
				try {
					choice = scanner.nextInt();
					switch (choice) {
					case 1: {
						do {
							System.out.println("Enter your Name");
							scanner = new Scanner(System.in);
							try {
								name = scanner.nextLine();
								service.isNameValid(name);
								flag = true;
							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							}

						} while (!flag);
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Email Id:");
							try {
								mailId = scanner.nextLine();
								service.isMailValid(mailId);
								mailIdFlag = true;
							} catch (BSException e) {
								mailIdFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mailIdFlag);

						do {
							System.out.println("Enter your Mobile Number");
							scanner = new Scanner(System.in);

							try {
								mobile = scanner.nextLong();
								service.isMobileValid(mobile);
								flag = true;
							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								flag = false;
								System.err.println("Enter only digits");
							}
						} while (!flag);

						do {
							System.out.println("Enter your Address");
							scanner = new Scanner(System.in);

							try {
								address = scanner.nextLine();
								service.isAddressValid(address);
								flag = true;
							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							System.out.println("Enter Initial Balance");
							scanner = new Scanner(System.in);

							try {
								initialBalance = scanner.nextDouble();
								service.isBalanceValid(initialBalance);
								flag = true;
							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								flag = false;
								System.err.println("Enter only digits");
							}
						} while (!flag);

						DateFormat df = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
						Date date = new Date();
						accountOpenDate = df.format(date);

						Account account = new Account(accountNumber, name, mailId, address, mobile, initialBalance,
								accountOpenDate, noOfTransactions);
						accountNumber = service.registerDetails(account);
						// System.out.println(account);
						System.out.println("Account created Successfully with Account number:" + accountNumber
								+ "\n\n Initial Balance: " + initialBalance);
					}
						break;
					case 2: {

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Account No. for deposit");
								accountNumber = scanner.nextLong();
								flag = service.isAccountValid(accountNumber);
							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								flag = false;
								System.err.println("Enter only digits with valid account number");
							}
						} while (!flag);

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Amount");
								amount = scanner.nextDouble();
								service.isAmountValid(amount);
								depositFlag = true;
							} catch (BSException e) {
								depositFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								depositFlag = false;
								System.err.println("Enter only digits");
							}

							if (amount > 0) {
								boolean deposit = service.amountDeposit(accountNumber, amount);
								if (deposit)
									System.out.println("Amount Deposited Successfully");
							}
						} while (!depositFlag);
					}

						break;
					case 3: {

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Account No. for withdraw");
								accountNumber = scanner.nextLong();
								flag = service.isAccountValid(accountNumber);

							} catch (BSException e) {
								flag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e1) {
								flag = false;
								System.err.println("Please enter only digits");
							}
						} while (!flag);

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Amount");
								amount = scanner.nextDouble();
								service.isAmountValid(amount);
								withdrawFlag = true;
							} catch (BSException e) {
								withdrawFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								withdrawFlag = false;
								System.err.println("Please enter only digits");
							}
						} while (!withdrawFlag);

						if (amount > 0) {
							boolean withdraw = service.amountWithdraw(accountNumber, amount);
							if (withdraw)
								System.out.println("Amount Withdrawn Successfully");
						}

					}

						break;
					case 4: {
						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter the Account Number");
								accountNumber = scanner.nextLong();
								service.isAccountNumberValid(accountNumber);
								finalBalance = service.viewBalance(accountNumber);
								System.out.println("Your bank balance is: " + finalBalance);
								viewFlag = true;
							} catch (BSException e) {
								viewFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								viewFlag = false;
								System.err.println("Please enter only digits");
							}
						} while (!viewFlag);
					}

						break;
					case 5: {

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Receiver's Account");
								receiverAccountNumber = scanner.nextLong();
								receiverFlag = service.isAccountValid(receiverAccountNumber);
							} catch (BSException e) {
								receiverFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								receiverFlag = false;
								System.err.println("Please enter only digits");
							}
						} while (!receiverFlag);

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Sender's Account");
								senderAccountNumber = scanner.nextLong();
								senderFlag = service.isAccountValid(senderAccountNumber);
							} catch (BSException e) {
								senderFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								senderFlag = false;
								System.err.println("Please enter only digits");
							}
						} while (!senderFlag);

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter Amount");
								amount = scanner.nextDouble();
								service.isAmountValid(amount);
								amountFlag = true;
							} catch (BSException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								amountFlag = false;
								System.err.println("Please enter digits only");
							}
						} while (!amountFlag);

						if (amount > 0) {

							generatedTransactionId = service.fundTransfer(receiverAccountNumber, senderAccountNumber,
									amount);
							System.out.println("Your Money transfer was successful: " + "\n Transaction Id: "
									+ generatedTransactionId);
						} else {
							System.err.println("Please enter valid credentials and continue");
						}

					}

						break;
					case 6: {
						do {
							scanner = new Scanner(System.in);

							try {
								System.out.println("Enter Account Number");
								accountNumber = scanner.nextLong();
								accountFlag = service.isAccountValid(accountNumber);

							} catch (BSException e) {
								accountFlag = false;
								System.err.println(e.getMessage());
							} catch (InputMismatchException e) {
								accountFlag = false;
								System.err.println("Please enter digits only");
							}
						} while (!accountFlag);

						List<Transaction> list = service.showAllTransactions(accountNumber);
						for (Iterator iterator = list.iterator(); iterator.hasNext();) {
							Transaction transaction = (Transaction) iterator.next();

							System.out.println(transaction);
						}

					}

						break;
					case 7: {
						Account account2 = new Account(accountNumber, name, mailId, address,  mobile, initialBalance,
								accountOpenDate, noOfTransactions);
						Map<Long, Account> map = service.viewCustomerDetails(account2);
						System.out.println(map);
					}
						break;
					case 8:
						System.out.println("Thankyou for your visit");
						System.exit(0);
						break;
					default:
						System.err.println("Please enter 1-7 only");
						break;
					}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("Please enter only Digits");
				}
			} while (!choiceFlag);
			do {
				System.out.println("do you want to continue again [yes/no]");
				scanner = new Scanner(System.in);
				option = scanner.nextLine();
				if (option.equalsIgnoreCase("yes")) {
					flag = true;
				} else if (option.equalsIgnoreCase("no")) {
					System.out.println("Thank You for Banking with us!!");
					flag = false;
					System.exit(0);
				} else {
					flag = false;
					System.err.println("Please enter only yes or no");
				}
			} while (!flag);
		} while (!optionFlag);

		scanner.close();

	}

}
