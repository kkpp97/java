package com.capgemini.bank.service;

import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BSException;

public interface BankingSoftwareService {

	long registerDetails(Account account);

	Map<Long, Account> viewCustomerDetails(Account account1);

	boolean amountDeposit(long destinationAccountr, double amount);

	boolean amountWithdraw(long accountNumber, double amount);

	double viewBalance(long accountNumber) throws BSException;

	long fundTransfer(long receiverAccountNumber, long senderAccountNumber, double amount);

	List<Transaction> showAllTransactions(long accountNumber);

	boolean isNameValid(String name) throws BSException;
	
	public boolean isMailValid(String mail) throws BSException;

	boolean isMobileValid(long mobile) throws BSException;

	boolean isAddressValid(String address) throws BSException;

	boolean isBalanceValid(double initialBalance) throws BSException;

	boolean isAmountValid(double amount) throws BSException;

	boolean isAccountNumberValid(long accountNumber) throws BSException;

	boolean isAccountValid(long accNumber) throws BSException;
	
	
}
