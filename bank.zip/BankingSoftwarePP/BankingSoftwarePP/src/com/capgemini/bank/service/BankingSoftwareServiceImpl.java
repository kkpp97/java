package com.capgemini.bank.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.dao.BankingSoftwareDao;
import com.capgemini.bank.dao.BankingSoftwareDaoImpl;
import com.capgemini.bank.exception.BSException;


public class BankingSoftwareServiceImpl implements BankingSoftwareService{
	
	BankingSoftwareDao bankingdao=new BankingSoftwareDaoImpl();
	Account account=new Account();
	
	@Override
	public long registerDetails(Account account) {
		
		return bankingdao.registerDetails(account);
	}

	@Override
	public Map<Long, Account> viewCustomerDetails(Account account1) {
		
		return bankingdao.viewCustomerDetails(account1);
	}

	@Override
	public boolean amountDeposit(long destinationAccount, double amount) {
		
		return bankingdao.amountDeposit(destinationAccount, amount);
	}

	@Override
	public boolean amountWithdraw(long accountNumber, double amount) {
		
		return bankingdao.amountWithdraw(accountNumber,amount);
	}

	@Override
	public double viewBalance(long accountNumber)throws BSException {
		
		return bankingdao.viewBalance(accountNumber);
	}

	@Override
	public long fundTransfer(long receiverAccountNumber, long senderAccountNumber, double amount) {
		
		return bankingdao.fundTransfer(receiverAccountNumber, senderAccountNumber, amount);
	}

	@Override
	public List<Transaction> showAllTransactions(long accountNumber) {
	
		return bankingdao.showAllTransactions(accountNumber);
	}

	@Override
	public boolean isNameValid(String name) throws BSException {
		String regEx="^[A-Z]{1}[A-Za-z ]{4,}$";
		boolean nameFlag=false;
		if(!Pattern.matches(regEx, name)) {
			throw new BSException("First letter should be capital and more than 5 digits");
		}else {
			nameFlag=true;
		}
		return nameFlag;
	}

	@Override
	public boolean isMobileValid(long mobile) throws BSException {
		boolean mobileValidFlag=false;
		String regEx2="^[6-9]{1}[0-9]{9}$";
		String phone=regEx2.valueOf(mobile);
		if(!Pattern.matches(regEx2, phone)) {
			throw new BSException("Mobile number should be of 10 digits");
		}else {
			mobileValidFlag=true;
		}
		return mobileValidFlag;
	}

	@Override
	public boolean isAddressValid(String address) throws BSException {
		String regEx2="^[A-Z]{1}[A-Za-z]{4,}$";
		boolean addressFlag=false;
		if(!Pattern.matches(regEx2, address)) {
			throw new BSException("First letter should be capital and more than 5 digits");
		}else {
			addressFlag=true;
		}
		return addressFlag;
	}

	@Override
	public boolean isBalanceValid(double initialBalance) throws BSException {
		boolean balanceFlag=false;
		if(initialBalance < 500) {
			throw new BSException("Minimum Balance 500 is required");
		}else {
			balanceFlag=true;
		}
		return balanceFlag;
	}

	@Override
	public boolean isAmountValid(double amount) throws BSException {
		double balance=account.getBalance();
		boolean amountFlag=false;
		if(amount <= 0) {
			throw new BSException("Enter valid Amount");
		}else {
			amountFlag=true;
		}
		return amountFlag;
	}

	@Override
	public boolean isAccountNumberValid(long accountNumber) throws BSException {
		boolean accountNumberValidFlag=false;
		String regEx2="^[8]{1}[0-9]{11}$";
		String account=regEx2.valueOf(accountNumber);
		if(!Pattern.matches(regEx2, account)) {
			throw new BSException(" Invalid Account Number ");
		}else {
			accountNumberValidFlag=true;
		}
		return accountNumberValidFlag;
		
	}
	
	public boolean isAccountValid(long accNumber) throws BSException{
		Account acc = bankingdao.getAccountDetails(accNumber);
		if(acc != null)
			return true;
		else
			throw new BSException("Entered account is not valid. Please try again");
	}

	@Override
	public boolean isMailValid(String mail) throws BSException {
		boolean resultFlag = false;
		String emailRegEx = "^[A-Za-z0-9+_.-]+@(.+)$";

		if (!Pattern.matches(emailRegEx, mail)) {
			throw new BSException("Invalid Email");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
}
