package com.capgemini.bank.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;

public class BankingRepository {

	static Map<Long, Account> detailStorage = new HashMap<>();
	static Map<Long, Transaction> transactionList = new HashMap<>();

	static {
		transactionList.put(1000000000011L,
				new Transaction(100000000011L, "debit", "10/12/19", 800000000010L, 800000000012L, 21000));
		transactionList.put(1000000000012L,
				new Transaction(100000000012L, "debit", "10/12/19", 800000000011L, 800000000013L, 22000));
		transactionList.put(1000000000013L,
				new Transaction(100000000013L, "debit", "10/12/19", 800000000012L, 800000000011L, 23000));
		transactionList.put(1000000000014L,
				new Transaction(100000000014L, "debit", "10/12/19", 800000000013L, 800000000010L, 24000));

		detailStorage.put(800000000010L,
				new Account(800000000010L, "Ankush","ankush@gmail.com", "Kalaburagi", 9999999999L, 1000, "10/12/19", 0));
		detailStorage.put(800000000011L,
				new Account(800000000011L, "Rishabh","rishabh@gmail.com", "Bengaluru", 9990000009L, 2000, "11/12/19", 0));
		detailStorage.put(800000000012L,
				new Account(800000000012L, "Rohit","rohit12@gmail.com", "Huballi", 9988899999L, 3000, "12/12/19", 0));
		detailStorage.put(800000000013L,
				new Account(800000000013L, "Akash","akash23@gmail.com", "Mysuru", 9999988889L, 4000, "13/12/19", 0));
	}

	public static Map<Long, Transaction> getTransactionList() {
		return transactionList;
	}

	public static void setTransactionList(Map<Long, Transaction> transactionList) {
		BankingRepository.transactionList = transactionList;
	}

	public static Map<Long, Account> getDetailStorage() {

		return detailStorage;
	}

	public static void setDetailStorage(Map<Long, Account> detailStorage) {
		BankingRepository.detailStorage = detailStorage;
	}

}
