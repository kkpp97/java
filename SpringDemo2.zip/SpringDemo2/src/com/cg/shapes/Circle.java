package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


public class Circle  {
	
	
	
	@Autowired
	private Point center;
	@Autowired
	MessageSource messageSource;

	public Point getCenter() {
		return center;
	}
     
	public void setCenter(Point center) {// can annotate only setter not a property like it should excute setter method 
		this.center = center;
	}
	
	public void draw() {
		
		String msg=messageSource.getMessage("greeting", null, "Default Greeting",null);
		System.out.println(msg);
		//System.out.println("circleDrawn");
		String draw=messageSource.getMessage("circle.drawing", null, "Default Drawing Msg", null);
		String points=messageSource.getMessage("circle.points", new Object[] {center.getX(),center.getY()},"Default Msg",null);
		System.out.println(points);
		System.out.println(draw);
	}
	
}
