package com.capgemini.bank.bean;

public class Transaction {
	private int accountNo;
	private int transactionId;
	private String transactionType;
	private String transactionDate;
	private double amount;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int accountNo, int transactionId, String transactionType, String transactionDate,
			double amount) {
		super();
		this.accountNo = accountNo;
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.amount = amount;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transaction [accountNo=" + accountNo + ", transactionId=" + transactionId + ", transactionType="
				+ transactionType + ", transactionDate=" + transactionDate + ", amount=" + amount + "]";
	}
	
}
