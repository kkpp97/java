package com.capgemini.bank.bean;

public class Customer {
	private long accountNo;
	private String customerName;
	private String customerEmail;
	private String customerMobileNo;
	private String customerAddress;
	private double balance;
	public Customer() {
		super();
	}
	
	public Customer(long accountNo, String customerName, String customerEmail, String customerMobileNo,
			String customerAddress, double balance) {
		super();
		this.accountNo = accountNo;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerMobileNo = customerMobileNo;
		this.customerAddress = customerAddress;
		this.balance = balance;
	}

	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerMobileNo=" + customerMobileNo + ", customerAddress=" + customerAddress
				+ ", balance=" + balance + "]";
	}
	}
	