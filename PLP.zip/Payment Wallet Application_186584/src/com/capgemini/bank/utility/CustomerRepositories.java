package com.capgemini.bank.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bank.bean.Customer;

public class CustomerRepositories {
	private static Map<Integer, Customer> customer = new HashMap<>();
	static {
customer.put(1001009090, new Customer(1001009090,"Haritha","harithareddy@gmail.com","9989898989","hyderabad",90000));
customer.put(1229089098, new Customer(1229089098,"Anusha","anusha@gmail.com","9908563434","Kukatpally",900000));
customer.put(1009089890, new Customer(1009089890,"Mounika","mounikareddy@gmail.com","9879965674","Bnaglore",900000));
customer.put(1998700345, new Customer(1998700345,"Srilatha","Srilatha@gmail.com","7844332908","Chennai",900000));
customer.put(1002345123, new Customer(1002345123,"Sharanya","Sharanya@gmail.com","9898786565","Mumbai",900000));


		
	}
	public static Map<Integer, Customer> getCustomers() {
		return customer;
	}

	public static void setCustomerDetails(Map<Integer, Customer> customers) {
		CustomerRepositories.customer = customers;
	}

}
