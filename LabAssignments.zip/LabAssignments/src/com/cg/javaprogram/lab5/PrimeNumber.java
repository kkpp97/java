package com.cg.javaprogram.lab5;

import java.util.Scanner;

public class PrimeNumber {
	public void printPrimeNumber(int number) {
		int flag =0;
		for(int i = 1;i<number;i++) {
			for(int j =2;j<i/2;j++) {
				if(i%j==0) {
					flag = 1;
					break;
			}
				else {
					System.out.println(i);
				}
		}
	}
}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		PrimeNumber number2 = new PrimeNumber();
		number2.printPrimeNumber(number);
		
	
	}
}
