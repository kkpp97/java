package com.cg.javaprogram.lab5;


	public class InvalidAgeException extends Exception {

		public InvalidAgeException(String message) {
			super(message);
		}

}


