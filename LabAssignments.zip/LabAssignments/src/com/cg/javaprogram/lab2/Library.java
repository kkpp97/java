package com.cg.javaprogram.lab2;

public class Library {
	 
	private int unique_id;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
