package com.cg.javaprogram.lab2;

public abstract class Items {
	private int unique_id;
	private String title;
	private int  number_of_copies;
	
	public Items(int unique_id, String title, int number_of_copies) {
		super();
		this.unique_id = unique_id;
		this.title = title;
		this.number_of_copies = number_of_copies;
	}

	public int getUnique_id() {
		return unique_id;
	}

	public void setUnique_id(int unique_id) {
		this.unique_id = unique_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNumber_of_copies() {
		return number_of_copies;
	}

	public void setNumber_of_copies(int number_of_copies) {
		this.number_of_copies = number_of_copies;
	}

	@Override
	public String toString() {
		return "Items [unique_id=" + unique_id + ", title=" + title + ", number_of_copies=" + number_of_copies + "]";
	}
	
	public abstract void print();
	public abstract void checkIn();
	
	
}
