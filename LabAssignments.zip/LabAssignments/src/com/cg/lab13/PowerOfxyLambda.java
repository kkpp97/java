//Write a lambda expression which accepts x and y numbers and return x^y
package com.cg.lab13;

import java.util.Scanner;

public class PowerOfxyLambda {
	public static void main(String[] args) {
		
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter two number to find power");
	int x = scanner.nextInt();
	int y = scanner.nextInt();

	ILambdaPowerxy powerobj = (a,b)-> (int) Math.pow(x,y);
	System.out.println(powerobj.power1(x,y));
	
	
	
	}
}
