//Write a method that uses lambda expression to format a given string, where a space
//is inserted between each character of string. For ex., if input is �CG�, then expected output is �C G�.
package com.cg.lab13;

import java.util.Scanner;

public class FormatWithSpace {
public static void main(String[] args) {
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("Enter name to format");
	String input1 = scanner.next();
	//String newstr=null;
	IInputFormat format=(s)->{
		String newstr="";
		for (int j = 0; j < s.length(); j++) {
			newstr+=s.charAt(j)+" ";
		}
		return newstr;	
	};
	System.out.println(format.FormatString(input1));
	}
}