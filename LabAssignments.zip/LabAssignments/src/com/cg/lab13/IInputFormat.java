package com.cg.lab13;

public interface IInputFormat {
	String FormatString(String input);
}
