package com.cg.lab13;

import java.util.Scanner;

public class UserPswrdAuthentication {
	public static void main(String[] args) {
	Scanner scanner= new Scanner(System.in);	
	System.out.println("Enter name to authenticate");
	String name = scanner.next();
	System.out.println("Enter password");
	String pwd = scanner.next();
	IUserPwdAuthenticate authenticate = (n,p)->(n==name && p==pwd)?true:false;
	System.out.println(authenticate.AuthenticatePwd(name, pwd));	
		
	
	}
}
