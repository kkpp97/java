//Write a method that uses lambda expression to accept username and password and
//return true or false.
package com.cg.lab13;


public interface IUserPwdAuthenticate {
	boolean AuthenticatePwd(String name,String password);
	
}
