package com.cg.lab13;

interface Say {
	void sayHi();
}

public class MethodReferenceForInstance {
	static void sayHi() {
		System.out.println("WElcome from method reference");
	}

	public static void main(String[] args) {
		Say say = MethodReferenceForInstance::sayHi;
		say.sayHi();
	}
}
