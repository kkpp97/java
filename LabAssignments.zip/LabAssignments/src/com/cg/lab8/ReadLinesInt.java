package com.cg.lab8;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;
public class ReadLinesInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrintWriter pw = new PrintWriter(System.out,true);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int sum = 0;
		try {
		System.out.println("Enter the numbers");
		String number = br.readLine();
		StringTokenizer st = new StringTokenizer(number,"");
		
		while(st.hasMoreElements()){
			String s=st.nextToken();
			System.out.println(s);
			sum = sum + Integer.parseInt(s);
			
			}
		
		}catch(NumberFormatException e) {
			
		}
	catch(IOException e) {
		
	}
		

}}
