package com.cg.lab9;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.List;
import java.util.Scanner;

public class SortedMapToList  {
	public List getValues(HashMap map) {
		
		Collection<String> collection = map.values();
		List<String> list = new ArrayList<String>();
		list.addAll(collection);
		Collections.sort(list);
		
		
		return list;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		HashMap<Integer,String> map = new HashMap<>();
		int option=-1;
		do {
		System.out.println("Enter Key");
		int key = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter Value");
		String value = scanner.next();
	
		map.put(key,value);
		System.out.println("press 1 to continue");
		option=scanner.nextInt();
		}while(option==1);
		System.out.println(new SortedMapToList().getValues(map));
	}
}