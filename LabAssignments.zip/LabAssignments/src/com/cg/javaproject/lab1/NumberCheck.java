package com.cg.javaproject.lab1;

import java.util.Scanner;

public class NumberCheck {

	boolean checkNumber(int number) {
		int storeLastDigit = 0;
		int storeSecLastDigit = 0;
		int flag = 0;
		while (number > 0) {

			storeLastDigit = number % 10; 
			number /= 10; //123
			storeSecLastDigit = number % 10; 

			if (storeLastDigit < storeSecLastDigit) {
				flag = 0;
				break;
			}
			flag = 1;
		}
		if (flag == 0) {
			return false;
		} else {
			return true;
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		NumberCheck check2 = new NumberCheck();
		System.out.println(check2.checkNumber(number));

	}

}
