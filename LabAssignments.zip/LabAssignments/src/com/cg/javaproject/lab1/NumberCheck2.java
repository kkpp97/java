package com.cg.javaproject.lab1;

import java.util.Scanner;

public class NumberCheck2 {
		
		boolean checkNumber(int number) {
			boolean result = true;
			while(number!=0) {
				
				if(number/2==1)
				{
					result = false;
					break;
				}
				
		
			}
			return result;
		

			}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number");
		int number = scanner.nextInt();
		
		NumberCheck2 check2 = new NumberCheck2();
		System.out.println(check2.checkNumber(number));
	}

}
