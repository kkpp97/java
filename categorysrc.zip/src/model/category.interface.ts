export class Category {
    id:number;
    fullname:string;
   }