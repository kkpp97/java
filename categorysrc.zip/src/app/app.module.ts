import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CategoryService } from 'src/app/category.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreatecategoryComponent } from './category/createcategory/createcategory.component';
import { ListcategoryComponent } from './category/listcategory/listcategory.component';
import { EditcategoryComponent } from './category/editcategory/editcategory.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    CreatecategoryComponent,
    ListcategoryComponent,
    EditcategoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CategoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
