import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatecategoryComponent } from './category/createcategory/createcategory.component';
import { ListcategoryComponent } from './category/listcategory/listcategory.component';
import { EditcategoryComponent } from './category/editcategory/editcategory.component';


const routes: Routes = [
  {path:'',component : ListcategoryComponent},
  {path:'create',component : CreatecategoryComponent},
  {path:'edit',component : EditcategoryComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
