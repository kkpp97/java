import { Injectable } from '@angular/core';
import { Category } from 'src/model/category.interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  
  categories:Category[];
  constructor(private http:HttpClient) { 
    this.getCategories().subscribe(data=>this.categories=data);
  }
  getCategories():Observable<Category[]>{
    return this.http.get<Category[]>("../../assets/category.json");
  }
  createCategory(category:Category){
    this.categories.push(category);
    }
  getData(){
    return this.categories;
  }
 getCategory(id:number){
  return this.http.get<Category[]>("../../assets/category.json"+id);
}
  setCategories(categories:Category[])
{
  this.categories=categories;
}

deleteCategory(category:Category){
    console.log(category);
return this.http.delete<Category[]>("../../assets/category.json/"+category.id);

 }

  
}
