import { Component, OnInit } from '@angular/core';
import { Category } from 'src/model/category.interface';
import { CategoryService } from 'src/app/category.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createcategory',
  templateUrl: './createcategory.component.html',
  styleUrls: ['./createcategory.component.css']
})
export class CreatecategoryComponent implements OnInit {
 
  categoryData:Category={"id":0,"fullname":'',};

  constructor(private categoryService:CategoryService,
    private router:Router) { }

  ngOnInit() {
  }
  create(){
    console.log(this.categoryData.fullname);
    this.categoryService.createCategory(this.categoryData);
  }

}
