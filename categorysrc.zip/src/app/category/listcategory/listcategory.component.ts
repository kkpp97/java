import { Component, OnInit } from '@angular/core';
import { Category } from 'src/model/category.interface';
import { CategoryService } from 'src/app/category.service';

@Component({
  selector: 'app-listcategory',
  templateUrl: './listcategory.component.html',
  styleUrls: ['./listcategory.component.css']
})
export class ListcategoryComponent implements OnInit {

  categories:Category[];
  constructor(private categoryService:CategoryService) { }

  ngOnInit() {
    if(!this.categoryService.getData()){
   
      if(!this.categoryService.getData()){
   
        this.categoryService.getCategories().subscribe(data=>{this.categories=data;
    this.categoryService.setCategories(this.categories);
    console.log(this.categories);
      });
    }
      else{
        this.categories=this.categoryService.getData();
      }
}
  }

deleteCategory(category:Category)
{
  this.categoryService.deleteCategory(category).subscribe(
    (data)=>{this.categories=this.categories.filter(c=>c!==category)});
}
  // constructor() { }

  // ngOnInit() {
  // }
  }
