package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;

public interface BankDao {
	
	public int createAccount(Customer customer, double amount) throws BankException;

	public double showBalance(int accountNo) throws BankException;

	List<Transaction> deposit(int accountNo, double amount) throws BankException;

	List<Transaction> withdraw(int accountNo, double amount) throws BankException;

	List<Transaction> fundTransfer(int sourceAccount, int destinationAccount, double amount) throws BankException;

	List<Transaction> PrintTransaction(int accountNo) throws BankException;

}
