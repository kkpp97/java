package com.cg;



import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scanner=new Scanner(System.in);
		Book book=new Book();
		Author1 author=new Author1();
		boolean flag=false;
		int choice=0;
		
		System.out.println("Enter the Details of Book & Author");
		System.out.println("1. Insert Book Details");
		System.out.println("2. Query all book detail");
		System.out.println("3. Query book by Author Name");
		System.out.println("4. List All books between range 500 to 1000");
		System.out.println("5. List Author name Based on book Id");
		
		do {
			System.out.println("Enter your choice");
			choice=scanner.nextInt();
		switch (choice) {
		case 1:{
			System.out.println("Enter Book ISBN ");
			int bookISBN=scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter Book Title");
			String bookTitle=scanner.nextLine();
			System.out.println("Enter Book Price");
			double bookPrice=scanner.nextDouble();
			scanner.nextLine();
			System.out.println("Enter Author Name");
			String authorName=scanner.nextLine();
			
			book.setISBN(bookISBN);
			book.setTitle(bookTitle);
			book.setPrice(bookPrice);
			author.setAuthorName(authorName);
			author.getBook().add(book);
		    book.setAuthor(author);
			
			em.getTransaction().begin();
			em.persist(book);
		    em.persist(author); 
		    em.getTransaction().commit();
			System.out.println("All Details Stored");
			
		}
			
			break;
		case 2:{
			TypedQuery<Book> tquery=em.createQuery("from Book",Book.class);
			List<Book> bookList=tquery.getResultList();
			for (Book book2 : bookList) {
				System.out.println(book2);
			}
		}
		break;
		case 3:{
			scanner.nextLine();
			System.out.println("Enter AuthorName");
			String authorName=scanner.nextLine();
			TypedQuery<Book> tquery=em.createQuery("select book from Author1 author join author.book book where author.authorName=?",Book.class);
			tquery.setParameter(1, authorName);
			List<Book> bookList1=tquery.getResultList();
			for (Book book4 : bookList1) {
				System.out.println(book4);
			}
		}
		break;
		case 4:{
			
			TypedQuery<Book> tquery=em.createQuery("from Book where price between 500 and 1000",Book.class);
			List<Book> bookList2=tquery.getResultList();
			for(Book book3: bookList2) {
				System.out.println(book3);
			}
		}
		break;
		case 5:{
			System.out.println("Enter Book Id");
			int bookId=scanner.nextInt();
			TypedQuery<Author1> tquery=em.createQuery("select author from Book book  where book.ISBN=?",Author1.class);
			tquery.setParameter(1, bookId);
			List<Author1> bookList3=tquery.getResultList();
			for (Author1 author1 : bookList3) {
				System.out.println(author1);
			}
		}
		break;
		default:
			break;
		}
		
		}while(!flag);
	}

}
