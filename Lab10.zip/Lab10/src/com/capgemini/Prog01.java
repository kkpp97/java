package com.capgemini;

public class Prog01 {

	public static void main(String[] args) {

	}

}
