import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }

  public showBalance(accountNumber) {
    if (accountNumber) {
      this.customerService.showBalance(accountNumber).subscribe(data => {
        this.message = 'Hello ' + data.fName + ' ' + data.lName + ', your Available balance is ' + data.amount;
  }, (err) => alert('Enter valid Account Number'));
} else {
  alert('Enter Account number!');
}

  }
}
