package com.demo.presentation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.demo.beans.ComplaintBean;
import com.demo.beans.ComplaintCategory;
import com.demo.exception.ComplaintException;
import com.demo.service.ComplainServiceImpl;
import com.demo.service.ComplaintService;

public class MainUI {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean choiceFlag = false;
		ComplaintService service = new ComplainServiceImpl();
		List<ComplaintCategory> list1 = new ArrayList<>();
		Map<String, String> map = null;

		do {

			try {
				map = new HashMap<>();
				map = service.getComplaintCategoryEnteries();
				Collection<String> collection = map.values();
				List<String> list11 = new ArrayList<>();
				list11.addAll(collection);
				Iterator<String> iterator = list11.iterator();
				int i = 1;
				while (iterator.hasNext()) {
					String name = iterator.next();
					System.out.println(i + ". " + name);
					i++;
				}

			} catch (ComplaintException e1) {
				e1.printStackTrace();
			}
			System.out.println("enter option");
			int choice = 0;
			try {
				choice = scanner.nextInt();
				switch (choice) {
				case 1: {
					System.out.println("enter Description");
					String description = scanner.next();
					scanner.nextLine();
					System.out.println("enter priority");
					String priority = null;
					boolean validPriority = false;
					do {

						try {
							priority = scanner.next();
							service.validPriority(priority);
							validPriority = true;

						} /*
							 * catch (InputMismatchException e) { // TODO: handle exception
							 * System.err.println("priority must be  high or low"); validPriority=false; }
							 */
						catch (ComplaintException e) {
							validPriority = false;
							System.out.println(e.getMessage());

						}
					} while (!validPriority);
					try {
						service.ComplaintStatusDisplay(description, priority);
						int registeredId = service.registerId();

						System.out.println("your complaint is registred with id   " + registeredId);
						System.out.println(LocalDate.now());
						ComplaintCategory complaintCategory = new ComplaintCategory();
						String comments = complaintCategory.getComments();
						System.out.println(comments);
						String status = complaintCategory.getComplaintStatus();
						System.out.println(status);
						ComplaintCategory comCategory = new ComplaintCategory(registeredId, description, priority,
								status, comments);

						list1.add(comCategory);
						System.out.println(list1);

					} catch (ComplaintException e) {
						e.printStackTrace();
					}

				}
					break;
				case 2: {

				}
					break;
				case 3: {

				}
					break;
				case 4: {

				}
					break;

				default:
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("choice must be digits");
			}
		} while (choiceFlag);
	}

}
