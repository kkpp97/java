package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public class MyBeanFactoryPP implements BeanFactoryPostProcessor {

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) throws BeansException {
		System.out.println("Bean Factory Post Processor Executed");
		Triangle t=(Triangle) factory.getBean("triangle");
		/*
		 * t.getPointA().setX(99); t.getPointA().setY(99); t.getPointB().setX(99);
		 * t.getPointB().setY(99); t.getPointC().setX(99); t.getPointC().setY(99);
		 */
	}
	

}
