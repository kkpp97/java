package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");//appln context is bean factory plus additional and the file should be within the class path
		//BeanFactory factory= new XmlBeanFactory(new FileSystemResource("spring.xml"));//bean factory is a container
		/*
		 * Triangle triangle=context.getBean("triangle",Triangle.class);
		 * triangle.draw(); context.registerShutdownHook();
		 */// as soon as main method ends container shuts down Abstract appln context is an parent of appln context
		//Circle c=(Circle)context.getBean("circle",Circle.class);
		//c.draw();
		context.registerShutdownHook();
		Employee e = (Employee) context.getBean("employee");
		System.out.println(e.getDob());
		
	}

}
