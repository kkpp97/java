package com.cg.prod.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.dao.ProductRepository;
import com.cg.prod.dto.Product;
import com.cg.prod.exception.ProductException;

@Service
public class ProductServiceImpl  implements ProductService{
	
	@Autowired
	private ProductRepository prodDao;

	@Override
	public Product addProduct(Product product) throws ProductException {
		prodDao.save(product);
		return product;
	}

	@Override
	public List<Product> updateProduct(int id, Product product) throws ProductException {
		if(prodDao.existsById(id)) {
			 Product prod=prodDao.findById(id).get();
	            prod.setPrice(product.getPrice());
	            prod.setQuantity(product.getQuantity());
	            prodDao.save(prod);
	            return getAllProducts();
	            
		}else {
			throw new ProductException("Invalid product");
		}
		
		
		
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		try {
			return prodDao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	
}
