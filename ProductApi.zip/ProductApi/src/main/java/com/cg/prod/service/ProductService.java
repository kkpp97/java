package com.cg.prod.service;

import java.util.List;

import com.cg.prod.dto.Product;
import com.cg.prod.exception.ProductException;

public interface ProductService {
	
	Product addProduct(Product product) throws ProductException;
	
	List<Product> updateProduct(int id, Product product) throws ProductException;
	
	List<Product> getAllProducts() throws ProductException;

}
