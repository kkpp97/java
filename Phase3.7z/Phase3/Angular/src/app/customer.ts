export class Customer {
  accountNumber: number;
  fName: string;
  lName: string;
  age: number;
  password: string;
  amount: number;

  constructor(fName: string, lName: string, age: number, password: string, amount: number) {
    this.fName = fName;
    this.lName = lName;
    this.age = age;
    this.password = password;
    this.amount = amount;
  }

}