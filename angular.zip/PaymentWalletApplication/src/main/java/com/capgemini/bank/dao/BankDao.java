package com.capgemini.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bank.bean.Accountdtls;
@Repository
public interface BankDao extends JpaRepository<Accountdtls, Integer>{


}
