package com.capgemini.bank.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.bank.bean.Transactiondtls;


@Repository
public interface TransactionDao 
extends JpaRepository<Transactiondtls, Integer>{

		@Query("from Transactiondtls where acct =:acc")
		  public List<Transactiondtls> getTransactionsByAccountNumber(@Param("acc") int accountNumber);
		  
		 

	}
