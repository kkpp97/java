package com.capgemini.bank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.bank.bean.Accountdtls;
import com.capgemini.bank.bean.Transactiondtls;
import com.capgemini.bank.service.BankService;


@CrossOrigin(origins="http://localhost:3300")
@RestController
public class BankController {
	@Autowired
	BankService bankService;

	
	@PostMapping
	public void createAccount(@RequestBody Accountdtls account) {
		bankService.createAccount(account);
	}

	@GetMapping
	public List<Accountdtls> showAccounts(){
		return bankService.showAllAccounts();
	}
	
	@GetMapping("/validate/{accountNumber}")
	public boolean depositAmount(@PathVariable("accountNumber") int accountNumber){
		return bankService.validateAccount(accountNumber);
	}
		
	@GetMapping("/{accountNumber}")
	public Accountdtls getAccount(@PathVariable("accountNumber") int accountNumber){
		return bankService.getAccountDetails(accountNumber);
	}
	@GetMapping("/balance/{accountNumber}")
	public Accountdtls showAccountBalance(@PathVariable("accountNumber") int accountNumber){
		return bankService.showBalance(accountNumber);
	}
	
	@PutMapping("/deposit/{accountNumber}")
	public Accountdtls depositAmount(@PathVariable("accountNumber") int accountNumber, @RequestBody Accountdtls account){
		return bankService.depositAmount(accountNumber,account);
	}
	
	@PutMapping("/withdraw/{accountNumber}")
	public Accountdtls withdrawAmount(@PathVariable("accountNumber") int accountNumber, @RequestBody Accountdtls account){
		return bankService.withdrawAmount(accountNumber,account);
	}
	
	@PutMapping("/transfer/{senderAccountNumber}/{recieverAccountNumber}")
	public Accountdtls fundTransfer(@PathVariable("senderAccountNumber") int senderAccountNumber, @PathVariable("recieverAccountNumber") int recieverAccountNumber, @RequestBody Accountdtls account){
		return bankService.fundTransfer(senderAccountNumber,recieverAccountNumber,account);
	}
	
	@GetMapping("/transactions/{accountNumber}")
    public List<Transactiondtls> getTransactionsByAccountNumber(@PathVariable("accountNumber") int accountNumber) {
        return bankService.getTransactionsByAccountNumber(accountNumber);
      
    }
 
	
}
