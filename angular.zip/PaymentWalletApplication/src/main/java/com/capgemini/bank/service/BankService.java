package com.capgemini.bank.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.bank.bean.Accountdtls;
import com.capgemini.bank.bean.Transactiondtls;

public interface BankService {



		public void createAccount(Accountdtls account);
		public boolean validateAccount(int accountNumber);
		public List<Accountdtls> showAllAccounts();
		public Accountdtls getAccountDetails(int accountNumber);
		public Accountdtls showBalance(int accountNumber);
		public Accountdtls depositAmount(int accountNumber, Accountdtls account);
		public Accountdtls withdrawAmount(int accountNumber, Accountdtls account);
		public Accountdtls fundTransfer(int senderAccountNumber, int recieverAccountNumber, Accountdtls account);
		public List<Transactiondtls> getTransactionsByAccountNumber(int accountNumber);

	}
