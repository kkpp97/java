package com.example.controller;





import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.el.MethodNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.example.entities.Order;
import com.example.exceptions.ExceptionResponse;
import com.example.exceptions.GlobalException;
import com.example.service.ServiceImpl;


@ControllerAdvice
@RestController
@RequestMapping("/order")
public class RestApiController {

	@Autowired
	private ServiceImpl ser;

	
	@PostMapping(value = "/add")
	 public List<Order> addUserData(@RequestBody final Order ord) {
		 if(ord.getQuantity() < 1) {
			 throw new GlobalException("Quantity must be greater than 0. ");
		 }
		 return ser.createOrder(ord);
	  }
	

	@GetMapping(value = "/viewall")
	public List<Order> viewAllOrder() {
		return ser.viewAllOrder();
	}
	
	 @PutMapping(value = "/update")
	 public List<Order> updateUserData(@RequestBody final Order ord) {

		 if(ser.updateOrder(ord) != null) {
			 return ser.updateOrder(ord);
		 }
		 else {
			 throw new GlobalException("id not found");
		 }
	
	 }
	 
	 @GetMapping(value = "/quantity/{quantity1}/{quantity2}")
		public List<Order> getByQuantity(@PathVariable final int quantity1,@PathVariable final int quantity2) {
			return ser.findByQuantity(quantity1,quantity2);
		}
	 
	 @GetMapping(value = "/amount/{amount}")
		public List<Order> getByAmount(@PathVariable final double amount) {
			return ser.findByAmount(amount);
		}
	
	

	 
	  @ExceptionHandler(GlobalException.class)

	  public final ResponseEntity<ExceptionResponse> handleNotFoundException(GlobalException ex, WebRequest request) {

	    ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(), ex.getMessage(),

	        request.getDescription(false),HttpStatus.NOT_ACCEPTABLE.getReasonPhrase());

	    return new ResponseEntity<ExceptionResponse>(exceptionResponse, HttpStatus.NOT_ACCEPTABLE);

	  }

	

	
}


