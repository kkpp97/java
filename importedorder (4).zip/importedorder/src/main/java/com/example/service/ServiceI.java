package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.entities.Order;

public interface ServiceI {

	List<Order> createOrder(Order ord);
	
	List<Order> viewAllOrder();
	
	List<Order> updateOrder(Order ord);
	
	List<Order> findByQuantity(int quantity1,int quantity2);
	
	List<Order> findByAmount(double amount);
	
//	Optional<Order> getByUserId(int id);
//	
//	Order getByUserName(String name);
//	
//	Order create(Order module);
//	
//	Boolean updateData(Order module);
//	
//	Boolean deleteData(int id);
//	
//	List<Order> findByFees(String fees);
//	
//	List<Order> findByRangeById(int id1,int id2);
	

	
}
