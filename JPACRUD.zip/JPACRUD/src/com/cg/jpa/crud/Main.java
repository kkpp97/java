package com.cg.jpa.crud;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {

		/*
		 * EntityManagerFactory factory =
		 * Persistence.createEntityManagerFactory("JPA-PU"); EntityManager em =
		 * factory.createEntityManager();
		 */
		Author author = new Author();
		Scanner scanner = new Scanner(System.in);

		int choice = 0;
		boolean flag = false;

		do {
			System.out.println("1.Insert Author Details");
			System.out.println("2.Update Author Details");
			System.out.println("3.Delete using Id");
			System.out.println("4.Display using Id");
			System.out.println("5.Exit");
			System.out.println("Enter Choice");
			choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				boolean iFlag = false;
				do {
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
					EntityManager em = factory.createEntityManager();
					em.getTransaction().begin();
					iFlag = true;
					System.out.println("Enter Author Id");
					int authorId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter First Name");
					String firstName = scanner.nextLine();
					System.out.println("Enter Middle Name");
					String middleName = scanner.nextLine();
					System.out.println("Enter Last Name");
					String lastName = scanner.nextLine();
					System.out.println("Enter Phone No");
					long phoneNo = scanner.nextLong();

					author.setAuthorId(authorId);
					author.setFirstName(firstName);
					author.setMiddleName(middleName);
					author.setLastName(lastName);
					author.setPhoneNo(phoneNo);
					em.persist(author);
					
					em.getTransaction().commit();
					em.close();
					System.out.println(" Data has been inserted into Database");

				} while (!iFlag);
			}
				break;

			case 2: {
				boolean uFlag = false;
				do {
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
					EntityManager em = factory.createEntityManager();
					System.out.println("Enter Id to update");
					int authorId = scanner.nextInt();
					em.getTransaction().begin();
					uFlag = true;
					Author author1 = em.find(Author.class, authorId);
					System.out.println("Enter FirstName");
					scanner.nextLine();
					String firstName = scanner.nextLine();
					System.out.println("Enter MiddleName");
					String middleName = scanner.nextLine();
					System.out.println("Enter LastName");
					String lastName = scanner.nextLine();
					System.out.println("Enter Phone No.");
					long phoneNo = scanner.nextLong();

					author1.setFirstName(firstName);
					author1.setMiddleName(middleName);
					author1.setLastName(lastName);
					author1.setPhoneNo(phoneNo);
					em.persist(author1);
					System.out.println("Data has been updated successfully");
					em.getTransaction().commit();
					em.close();
				} while (!uFlag);
			}
				break;
			case 3: {
				boolean dFlag = false;
				do {
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
					EntityManager em = factory.createEntityManager();
					System.out.println("Enter Id to delete");
					int authorId1 = scanner.nextInt();
					em.getTransaction().begin();
					dFlag = true;
					Author author2 = em.find(Author.class, authorId1);
					em.remove(author2);
					em.getTransaction().commit();
					System.out.println("Author with Id" + authorId1 + " removed successfully");
					em.close();
				} while (!dFlag);
			}
				break;
			case 4: {
				boolean dFlag = false;
				do {
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
					EntityManager em = factory.createEntityManager();
					System.out.println("Enter Id to View Author Details");
					int authorId2 = scanner.nextInt();
					em.getTransaction().begin();
					dFlag = true;
					Author author3 = em.find(Author.class, authorId2);
					System.out.println(author3);
					em.getTransaction().commit();
					em.close();
				} while (!dFlag);
			}
				break;
			case 5:
				System.out.println("Thank u");
				System.exit(0);
				break;
			default:
				System.err.println("Please enter 1,2,3 or 4 only");
				break;
			}
		} while (!flag);
	}

}
