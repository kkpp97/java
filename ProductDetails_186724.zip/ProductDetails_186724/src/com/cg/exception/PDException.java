package com.cg.exception;

public class PDException extends Exception{
	public PDException(String message) {
		super(message);
	}

}
