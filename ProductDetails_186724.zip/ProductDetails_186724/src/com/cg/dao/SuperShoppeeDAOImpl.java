package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.bean.Supplier;
import com.cg.exception.PDException;

public class SuperShoppeeDAOImpl implements ISuperShoppeDAO {

	@Override
	public int addProduct(Product product) throws PDException {
		int productId= (int) (Math.random() * 1000);// gives huge numbers Method-1
		// Random random=new Random(1000); Gives less numbers Method-2 usually not
		// preferred
		product.setProductId(productId);
		
		return productId;
		
	}

	@Override
	public int addSupplier(Supplier sup) throws PDException {
		int supplierId= (int) (Math.random() * 1000);// gives huge numbers Method-1
		// Random random=new Random(1000); Gives less numbers Method-2 usually not
		// preferred
		sup.setSupplierId(supplierId);
		return supplierId;
		
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() throws PDException {
		
		return productList;
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() throws PDException {
		
		return supplierList;
	}

}
