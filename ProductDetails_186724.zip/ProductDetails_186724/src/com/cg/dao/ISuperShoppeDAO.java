package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.bean.Supplier;
import com.cg.exception.PDException;

public interface ISuperShoppeDAO {
	
	HashMap<Integer, Product>productList=new HashMap<>();
	
	HashMap<Integer, Supplier>supplierList=new HashMap<>();
	
	public int addProduct(Product product) throws PDException;
	
	public int addSupplier(Supplier sup) throws PDException;
	
	public HashMap<Integer, Product>getAllProducts() throws PDException;
	
	public HashMap<Integer, Supplier>getAllSuppliers() throws PDException;

}
