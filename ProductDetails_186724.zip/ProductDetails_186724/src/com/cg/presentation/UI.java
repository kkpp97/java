package com.cg.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.bean.Supplier;
import com.cg.exception.PDException;
import com.cg.service.ISuperShoppeService;
import com.cg.service.SupperShoppeServiceImpl;


public class UI {
	
	public static void main(String[] args) {
		
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {
			System.out.println("****Welcome to product details application*****");
			System.out.println("1.Add Product");
			System.out.println("2.Add Supplier");
			System.out.println("3.Display product");
			System.out.println("4.Display Supplier");
			System.out.println("5.Exit");
			
			ISuperShoppeService service= new SupperShoppeServiceImpl();
			
			int choice = 0;
			boolean choiceFlag = false;
			

			do {
				scanner = new Scanner(System.in);
				try {
					System.out.println("Enter input:");
					choice = scanner.nextInt();
					choiceFlag = true;
					
					boolean productNameFlag = false;
					String productName = "";
					
					boolean supplierNameFlag = false;
					String supplierName = "";
					
					boolean mobileNoFlag = false;
					double suppliermobileNo=0;
					
					
					
					switch(choice) {
					
					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Product name:");
							productName = scanner.nextLine();
							try {
								service.validateProductName(productName);
								productNameFlag=true;
							} catch (PDException e) {
								productNameFlag=false;
								System.err.println(e.getMessage());
							}
						} while(!productNameFlag);
						
						
						System.out.println("Enter price:");
						double price = scanner.nextDouble();
						
						System.out.println("Enter quantity:");
						int quantity = scanner.nextInt();
						
						Product product=new Product(productName, price, quantity);
						
						try {
							int genearatedId = service.addProduct(product);
							System.out.println("product stored with the given id: " + genearatedId);
						} catch (PDException e) {
							System.err.println(e.getMessage());
						}
						break;
						
					case 2:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Supplier name:");
							supplierName = scanner.nextLine();
							
							try {
								service.validatesupplierName(supplierName);
								supplierNameFlag=true;
							} catch (PDException e) {
								supplierNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!supplierNameFlag);
						
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Mobile number:");
							suppliermobileNo = scanner.nextDouble();
							
							try {
								service.validatesuppliermobileNo(suppliermobileNo);
								mobileNoFlag=true;
							} catch (PDException e) {
								mobileNoFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!mobileNoFlag);
						
						System.out.println("Enter Address:");
						String address = scanner.nextLine();
						
						Supplier sup=new Supplier(supplierName, suppliermobileNo, address);
						
						try {
							int genearatedId = service.addSupplier(sup);
							System.out.println("product stored with the given id: " + genearatedId);
						} catch (PDException e) {
							System.err.println(e.getMessage());
						}
						
					case 3:
						HashMap<Integer, Product> productList;
						try {
							productList = service.getAllProducts();
							System.out.println(productList);
						} catch (PDException e) {
							System.err.println(e.getMessage());
						}
							
						break;
					case 4:
						HashMap<Integer, Supplier> supplierList;
						try {
							supplierList = service.getAllSuppliers();
							System.out.println(supplierList);
						} catch (PDException e) {
							System.err.println(e.getMessage());
						}
						break;
					case 5:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}	
			} while (!choiceFlag);
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

					
		} while (continueValue);
		scanner.close();
	}

}
