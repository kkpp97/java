package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.bean.Supplier;
import com.cg.exception.PDException;


public interface ISuperShoppeService {
	
	public boolean validateProductName(String productName) throws PDException;

	public boolean validateProductId(int productId) throws PDException;
	
	public boolean validatesupplierName(String supplierName) throws PDException;

	public boolean validatesupplierId(int supplierId) throws PDException;
	
	public boolean validatesuppliermobileNo(double suppliermobileNo) throws PDException;
	
	public int addProduct(Product product) throws PDException;
	
    public int addSupplier(Supplier sup) throws PDException;
	
	public HashMap<Integer, Product>getAllProducts() throws PDException;
	
	public HashMap<Integer, Supplier>getAllSuppliers() throws PDException;
	
	

}
