package com.cg.service;

import java.util.HashMap;
import java.util.regex.Pattern;


import com.cg.bean.Product;
import com.cg.bean.Supplier;
import com.cg.dao.ISuperShoppeDAO;
import com.cg.dao.SuperShoppeeDAOImpl;
import com.cg.exception.PDException;



public class SupperShoppeServiceImpl implements ISuperShoppeService {
	ISuperShoppeDAO supershoppedao=new SuperShoppeeDAOImpl();

	@Override
	public boolean validateProductName(String productName) throws PDException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,}";
		
		if (!Pattern.matches(nameRegEx, productName)) {
			throw new PDException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		
	}

	@Override
	public boolean validateProductId(int productId) throws PDException {
		boolean idFlag=false;
		String idRegEx = "[0-9]{3}";
		if (!Pattern.matches(idRegEx, String.valueOf(productId))) {
			throw new PDException("id should be 3 digit number \n");
		}else {
			idFlag=true;
		}
		
		return idFlag;
	}

	@Override
	public boolean validatesupplierName(String supplierName) throws PDException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,}";
		
		if (!Pattern.matches(nameRegEx, supplierName)) {
			throw new PDException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		
		
		
	}

	@Override
	public boolean validatesupplierId(int supplierId) throws PDException {
		boolean idFlag=false;
		String idRegEx = "[0-9]{3}";
		if (!Pattern.matches(idRegEx, String.valueOf(supplierId))) {
			throw new PDException("id should be 3 digit number \n");
		}else {
			idFlag=true;
		}
		
		return idFlag;
		
		
		
	}

	@Override
	public boolean validatesuppliermobileNo(double suppliermobileNo) throws PDException {
		boolean mobileNoFlag=false;
		String  mobileNoRegEx = "[7-9]{1}[0-9]{9}";
		if (!Pattern.matches(mobileNoRegEx, String.valueOf(suppliermobileNo))) {
			throw new PDException("Mobile number should be 10 digit number \n");
		}else {
			mobileNoFlag=true;
		}
		
		return mobileNoFlag;
		
		
		
	}

	@Override
	public int addProduct(Product product) throws PDException {
		
		return supershoppedao.addProduct(product);
	}

	@Override
	public int addSupplier(Supplier sup) throws PDException {
		
		return supershoppedao.addSupplier(sup);
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() throws PDException {
		
		return supershoppedao.getAllProducts();
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() throws PDException {
		
		return supershoppedao.getAllSuppliers();
	}

}
