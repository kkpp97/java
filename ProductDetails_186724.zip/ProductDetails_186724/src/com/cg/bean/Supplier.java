package com.cg.bean;

public class Supplier {
	
	private int supplierId;
	private String suppliername;
	private double suppliermobileNo;
	private String address;
	
	
	public Supplier() {
		super();
		
	}
	

	public Supplier(String suppliername, double suppliermobileNo, String address) {
		super();
		this.suppliername = suppliername;
		this.suppliermobileNo = suppliermobileNo;
		this.address = address;
	}



	public Supplier(int supplierId, String suppliername, double suppliermobileNo, String address) {
		super();
		this.supplierId = supplierId;
		this.suppliername = suppliername;
		this.suppliermobileNo = suppliermobileNo;
		this.address = address;
	}


	public int getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}


	public String getName() {
		return suppliername;
	}


	public void setName(String suppliername) {
		this.suppliername = suppliername;
	}


	public double getMobileNo() {
		return suppliermobileNo;
	}


	public void setMobileNo(double suppliermobileNo) {
		this.suppliermobileNo = suppliermobileNo;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", name=" + suppliername + ", mobileNo=" + suppliermobileNo + ", address="
				+ address + "]";
	}
	
	
	

}
