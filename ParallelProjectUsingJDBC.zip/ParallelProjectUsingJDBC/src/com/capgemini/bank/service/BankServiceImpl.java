package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.dao.BankDaoImpl;
import com.capgemini.bank.dao.IBankDao;
import com.capgemini.bank.exception.BankException;

public class BankServiceImpl implements IBankService {
	IBankDao bankDao=new BankDaoImpl();
	@Override
	public int createAccount(Customer customer, double amount) throws BankException {
		return bankDao.createAccount(customer,amount);
	}

	@Override
	public double showBalance(int accountNo) throws BankException {
		return bankDao.showBalance(accountNo);
	}

	@Override
	public List<Transaction> deposit(int accountNo, double amount) throws BankException {
		return bankDao.deposit(accountNo, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountNo, double amount) throws BankException {
		return bankDao.withdraw(accountNo, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankException {
		return bankDao.fundTransfer(sourceAccount, destinationAccount, amount);
	}

	@Override
	public List<Transaction> PrintTransaction(int accountNo) throws BankException {
		return bankDao.PrintTransaction(accountNo);
	}

}
