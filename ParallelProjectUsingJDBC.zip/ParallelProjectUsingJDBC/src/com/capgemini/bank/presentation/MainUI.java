package com.capgemini.bank.presentation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.BankServiceImpl;

public class MainUI {
	static Scanner scanner=new Scanner(System.in);
	static BankServiceImpl service=new BankServiceImpl();
	public static void main(String[] args) {
		boolean choiceFlag=false;
		do {
		System.out.println("***Welcome to XYZ bank***");
		System.out.println("1) Create Account");
		System.out.println("2) Show Balance");
		System.out.println("3) Deposit");
		System.out.println("4) Withdraw");
		System.out.println("5) Fund Transfer");
		System.out.println("6) Print Transaction");
		System.out.println("Enter your choice: ");
		int choice=scanner.nextInt();
		switch(choice) {
		case 1:CreateAccount();
		break;
		case 2:ShowBalance();
		break;
		case 3:deposit();
		break;
		case 4:withdraw();
		break;
		case 5:fundTransfer();
		break;
		case 6:printTransactions();
		break;
		}
		}while(!choiceFlag);
	}
	private static void printTransactions() {
		System.out.println("Enter your account number: ");
		int accountNo=scanner.nextInt();
		try {
			List<Transaction> transactionList=service.PrintTransaction(accountNo);
			System.out.println(transactionList);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void fundTransfer() {
		System.out.println("Enter your account number: ");
		int sourceAccountNo=scanner.nextInt();
		System.out.println("Enter destination account number: ");
		int destinationAccountNo=scanner.nextInt();
		System.out.println("Enter the amount you want to withdraw: ");
		double amount=scanner.nextDouble();
		try {
			List<Transaction> transactionList=service.fundTransfer(sourceAccountNo, destinationAccountNo, amount);
			System.out.println(transactionList);
		} catch (BankException e) {
			e.printStackTrace();
		}
	}
	private static void withdraw() {
		System.out.println("Enter your account number: ");
		int accountNo=scanner.nextInt();
		System.out.println("Enter the amount you want to withdraw: ");
		double amount=scanner.nextDouble();
		try {
			List<Transaction> transactionList=service.withdraw(accountNo, amount);
			System.out.println(transactionList);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void deposit() {
		System.out.println("Enter your account number: ");
		int accountNo=scanner.nextInt();
		System.out.println("Enter the amount you want to deposit: ");
		double amount=scanner.nextDouble();
		try {
			List<Transaction> transactionList=service.deposit(accountNo, amount);
			System.out.println(transactionList);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void ShowBalance() {
		System.out.println("Enter your account number: ");
		int accountNo=scanner.nextInt();
		try {
			double balance=service.showBalance(accountNo);
			System.out.println("balance for the account no is: "+balance);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void CreateAccount() {
		scanner.nextLine();
		System.out.println("enter customer name: ");
		String customerName=scanner.nextLine();
		System.out.println("Enter customer email: ");
		String customerEmail=scanner.nextLine();
		System.out.println("Enter customer mobile: ");
		String customerMobile=scanner.nextLine();
		System.out.println("Enter customer address: ");
		String customerAddress=scanner.nextLine();
		System.out.println("Enter the initial amount you want to deposit: ");
		double amount=scanner.nextDouble();
		Customer customer=new Customer(0,customerName,customerEmail,customerMobile,customerAddress,0,0);
		try {
			int accountNo=service.createAccount(customer,amount);
			System.out.println("Customer Account created successfully with accountno "+accountNo);
		} catch (BankException e) {
			e.printStackTrace();
		}
	}
}
