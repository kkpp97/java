package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


public class Circle {
	
	@Autowired
	private Point center;

	public Point getCenter() {
		return center;
	}
     
	public void setCenter(Point center) {// can annotate only setter not a property like it should excute setter method 
		this.center = center;
	}
	
	public void draw() {
		System.out.println("circleDrawn");
		System.out.println("Circle Points ("+center.getX()+","+center.getY()+")");
	}
	@PostConstruct
	public void myInit() {
		System.out.println("My Init method executed");
	}
     @PreDestroy
	public void myDestroy() {
		System.out.println("My Destroy method executed");
	}
}
