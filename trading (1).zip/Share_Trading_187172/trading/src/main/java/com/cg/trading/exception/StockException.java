package com.cg.trading.exception;

@SuppressWarnings("serial")
public class StockException extends Exception {

//	****CONSTRUCTORS****
	
	public StockException() {
		super();
	}
	
	public StockException(String message) {
		super(message);
	}
	
}