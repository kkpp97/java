package com.cg.cust.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer {
	@Id
	private int id;
	@Pattern(regexp = "[A-Z][A-Za-z\\s]{2,}",message="Name should start with a Capital letters")
	private String name;
	@NotEmpty(message = "Gender field is Mandatory") //@Pattern(regexp = "(Male|Female)") if it was a text box
	private String gender;
	@Pattern(regexp = "(PRIV|GEN)",message = "Customer Type should be either Priv or GEN")
	private String type;
	@Min(1) @Max(10)
	private int rating;
	@Pattern(regexp ="\\d{10}",message = "Mobile Number should be 10 digits only")
	private String mobile;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", gender=" + gender + ", type=" + type + ", rating=" + rating
				+ ", mobile=" + mobile + "]";
	}
	
	

}
